Hooks.on('init', ()=> {
    game.settings.register('token-lean', 'sourceToken', {
        config: false,
        type: String,
        scope: 'client'
    })

    game.settings.register('token-lean', 'visionToken', {
        config: false,
        type: String,
        scope: 'client'
    })
    
    
    game.settings.register('token-lean', 'limit', {
        name: game.i18n.localize('token-lean.Limit.Name'),
        hint: game.i18n.localize('token-lean.Limit.Hint'),
        config: true,
        type: Number,
        scope: 'world',
        default: 0.25,
        onChange: value => {
            game.settings.set('token-lean', 'limit', Math.max(value, -0.5))
        }
    })
    
    game.keybindings.register('token-lean', 'lean', {
        name: game.i18n.localize('token-lean.Keybind.Name'),
        hint: game.i18n.localize('token-lean.Keybind.Hint'),
        editable: [{key: 'KeyQ'}],
        onDown: () => {
            if (canvas.tokens.controlled[0]?.vision?.active === true) {
                game.settings.set('token-lean', 'sourceToken', canvas.tokens.controlled[0].id)
                createVisionToken()
                // document.addEventListener('mousemove', lean)
            }
        },
        onUp: () => {
            destroyVisionToken()
            // document.removeEventListener('mousemove', lean)
        },
        repeat: false
    })
})

async function createVisionToken () {
    const sourceToken = canvas.tokens.get(game.settings.get('token-lean', 'sourceToken'))
    const sourceTokenData = sourceToken.data
    sourceTokenData.x -= 200
    const visionToken = await getDocumentClass('Token').create(sourceTokenData, {parent: canvas.scene})
    game.settings.set('token-lean', 'visionToken', visionToken.id)
    const t = canvas.tokens.get(visionToken.id)
    t.control()
}

async function destroyVisionToken () {
    const t = canvas.tokens.get(game.settings.get('token-lean', 'visionToken'))
    await t.document.delete()
    const o = canvas.tokens.get(game.settings.get('token-lean', 'sourceToken'))
    o.control()
}