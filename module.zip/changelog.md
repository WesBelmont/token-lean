# 2.0.0
- Rewrite of almost the entire code base.
- Token leaning is visible to other players.
- Tokens can no longer lean when the game is paused.
- The tokens actually move, which means if a player leans over a trigger, it will be set off.
- Movement caused by leaning is ignored by the history buffer, so you can still undo events properly.
- Added option to allow/disallow leaning in combat.

## 1.1.2
- fixed it... I think. I dunno what happened, It just went and died on me.
- it was throwing errors left right and centre, but now it's not.
- and it doesn't seem to die if dependencies are not installed.

## 1.1.1
- fixed compatibilty loading
- added libWrapper and perfect-vision as dependencies

## 1.1.0
- Added Levels compatability.
- Made some changes to increase stability and maybe performance.

## 1.0.2
- updated manifest to include bugs and readme

## 1.0.1
- removed debug code from relase

## 1.0.0
- First release